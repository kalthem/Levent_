//
//  ViewController.swift
//  Levent
//
//  Created by k 3 on 04/12/2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
}

